package amazingco;

public class PickingPointSystemTest {
	
}
