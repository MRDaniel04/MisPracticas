package amazingco;

public class KioskTest {

}
