package amazingco;

public class PickingPointHubTest {

}
